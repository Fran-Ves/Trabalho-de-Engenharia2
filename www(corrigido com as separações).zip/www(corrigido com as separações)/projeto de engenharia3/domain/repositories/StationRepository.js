export default class StationRepository {
  async getAll() {}
  async getById(id) {}
  async save(station) {}
  async delete(id) {}
  async search(query) {}
}