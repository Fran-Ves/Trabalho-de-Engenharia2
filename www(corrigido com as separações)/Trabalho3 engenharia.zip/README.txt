https://github.com/Fran-Ves/Trabalho-de-Engenharia2

Esse trabalho de engenharia contém a plataforma de gps e mapeamento AbasteceAí feita por: Francisco das Chagas, Tiago Lima, Kal Rogers e Pedro Kawan. Esta versão possui uma arquitetura em camadas e uma arquitetura orientada a eventos na parte de banco de dados.